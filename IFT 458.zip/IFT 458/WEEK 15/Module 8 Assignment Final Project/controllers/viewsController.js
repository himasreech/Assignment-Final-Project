const axios = require('axios');
const User = require('./../models/userModel');
const courses = require('./../dev-data/data/courses.json');

exports.home = async (req, res) => {
  if (req.session.userId){
    User.findById(req.session.userId)
    .exec(function (error, user) {
      if (error) {
        res.status(200).render('overview', {
          title: `Over View`
        
        });
      } else {
        return res.render('overview', { title: 'Over View', name: user.name});
      }
      req.session.name = user.name
    }); 
  }
  else {
    res.status(200).render('overview', {
    title: `Over View`
  });
  }
};

// controller for creating a new loan
exports.CreateNewLoan = (req, res) => {
  res.status(200).render('newLoan', {
    title: 'Create New Loan',
    name: req.session.name
  });
};

// controller for viewing all the loan list
exports.getLoanList = async (req, res) => {
  const query = await axios.get('http://localhost:3000/api/v1/loans')
  res.status(200).render('loanlists', {
    title: `Loan List`,
    "loans": query.data.loans
  });
};

// controller for viewing user loans
exports.getUserLoan = async (req, res) => {

  // console.log(req.session)
  const query = await axios.get('http://localhost:3000/api/v1/loans/user',{params:{name:req.session.name}})
  // console.log(query.data.loans)
  res.status(200).render('userLoan', {
    title: `Get loanlists`,
    "loans": query.data.loans,
    name: req.session.name
  });
};

exports.getCourse = async (req, res) => {
  res.status(200).render('courses', {
    title: `Get Course`
  });
};

exports.courseList = async (req, res) => {
  res.status(200).render('allCourses', {
    title: `List of courses`,
    "courses": courses
  });
};

exports.createNewCourse = async (req, res) => {
  res.status(200).render('newCourse', {
    title: `Create New Course`
  });
};

exports.getSignInForm = (req, res) => {
  res.status(200).render('newUser', {
    title: 'Sign in New User'
  });
};

exports.getLoginForm = (req, res) => {
  res.status(200).render('login', {
    title: 'Log into your account'
  });
};

exports.getAllUser = async (req, res) => {

  // console.log(req.session)
  const query = await axios.get('http://localhost:3000/api/v1/users/')
  // console.log(query.data)
  res.status(200).render('userlist', {
    title: `Get userlists`,
    "users": query.data.users,
    name: req.session.name
  });
};

exports.logout = (req, res) => {
  if (req.session) {
    // delete session object
    req.session.destroy(function(err) {
      if(err) {
        return next(err);
      } else {
        return res.redirect('/');
      }
    });
  }
};
