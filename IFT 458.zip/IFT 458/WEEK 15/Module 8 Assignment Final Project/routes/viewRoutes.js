const express = require('express');
const viewsController = require('../controllers/viewsController');

const router = express.Router();

router.get('/', viewsController.home);
router.get('/login', viewsController.getLoginForm);
router.get('/signIn', viewsController.getSignInForm);
router.get('/newCourse', viewsController.createNewCourse)
router.get('/Course', viewsController.getCourse);
router.get('/courseList', viewsController.courseList)
router.get('/newloan', viewsController.CreateNewLoan);
router.get('/loans', viewsController.getLoanList);
router.get('/loanlist', viewsController.getUserLoan);
router.get('/userlist', viewsController.getAllUser);
router.get('/logout', viewsController.logout);

module.exports = router;
